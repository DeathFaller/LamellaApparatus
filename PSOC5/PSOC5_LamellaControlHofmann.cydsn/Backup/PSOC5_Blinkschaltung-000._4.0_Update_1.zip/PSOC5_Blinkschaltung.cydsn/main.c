/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
https://www.segger.com/downloads/emfile/UM02001_emFile.pdf

*/
#include <project.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <FS.h>
#include <string.h>

#define InitLED_ON Pin_LED_Write(1)
#define InitLED_OFF Pin_LED_Write(0)

volatile int NumberOfMeasurements = 0;          // Anzahl durchzuführender Messungen als globale Variable definieren

int ADC_value;                                  // letzter Messwert des ADC
volatile int Number[1000];                      // Ergebnisarray für Nummer der Messung
volatile int Lifetime[1000];                    // Ergebnisarray für Lebenszeit der jewiligen Lamelle

volatile int Lifetime_max = 0;                  // Maximale Lebenszeit

volatile char menustate = 0;                    // Momentaner Menüstand als globale Variable definieren

volatile char RX_Buffer[4];                     // Array aus 4 Bytes, das den Wert des Sliders enthält

volatile int counter_Timer1_steps = 0;          // Zähler für Durchläufe der Timerfuktion 
volatile int counter_Lamella_Number = 0;        // Zähler für die Anzahl der zu betrachtenden Lamellen

//const int Lamella_Relaxation_Time_s = 1;        // Zeit, die der Lamelle gegeben wird, bis sich konstantes Signal einstellt in s
int counter_Lamella_Relaxation_steps;           // "Gnadenfrist" in timer Steps 
//const int Maximum_Lamella_Time_h = 1;           // Maximal "erlaubte" Lebenszeit einer Lamelle in [h], danach wird neue ausgebildet
int counter_Maximum_Lamella_Time_steps;         // Maximal "erlaubte" Lebenszeit in steps
//const int Rupture_Confirmation_Time_s = 1;      // Zeit, die das Signal, den Grenzwert unterschreiten muss, damit Lamelle als gerissen zählt
int counter_Rupture_Confirmation_Target;        // Target-Counts, die Signal unter dem Grenzwert bleiben musss
int counter_Rupture_Confirmation = 0;           // Momentaner Zählerstand der Unterschreitungen des Grenzwertesin
int bool_Rupture_Confirmed = 0;                 // Bool, die angibt, ob die aktuelle Lamelle als gerissen angesehen wird

int WidthOfBin;                                 // Breite einer "Bin" für Darstellung auf Seite "ScaledData"

volatile char timerflag100ms = 0;               // Flag für 100ms Timer
volatile char timerflag1000ms = 0;              // Falg für 1000ms Timer
volatile char timerflag5000ms = 0;              // Falg für 1000ms Timer

volatile int cnt_timer100ms =0;                 // Counter für 100ms Takt
volatile int cnt_timer1000ms =0;                // Counter für 1000ms Takt
volatile int cnt_timer5000ms =0;                // Counter für 5000ms Takt

volatile char slider_ready = 0;                         // Boolean, die angibt, ob Slider bereit ist, Werte auszulesen; global definiert
volatile char Measurement_running = 0;                  // Boolean, die angibt, ob bereits eine Messung läuft
int present_Result_saved = 0;                           // Boolean, die angibt, ob zuletzt gemessene Lebenszeit schon in Array geschrieben wurde                 
volatile char new_pickup_initialized = 0;               // Boolean, die angibt, dass gerade eine neue Lamelle geholt wird
volatile char slider_val_sent = 0;                      // Boolean für Abfrage, ob Slider-Wert angefragt wurde
volatile char slider_val_received = 0;                  // Boolean für Abfrage, ob Slider-Wert ausgelesen wurde
volatile int present_LiveData_plot_refreshed = 0;       // Boolean, die angibt, ob in der momentanen Zeichenfläche die Zeichung aktualisiert wurde
volatile int current_RescaledData_plot_refreshed = 0;   // Boolean, die angibt, ob in der momentanen Zeichenfläche "RescaledData" die Zeichung aktualisiert wurde
volatile int STI100_writing = 0;                        // Boolean, die angibt, ob gerade Daten auf USB geschrieben werden
volatile int STI100_write_requested = 0;                // Boolean, die angibt, ob Anfrage auf Schreiben der auf USB gestellt wurde
volatile int STI100_present_results_saved = 0;          // Boolean, die angibt, dass die zuletzt gewonnen Messwert noch nicht gesteichert wurden     

char num_str[20];                               // Hilfvariable, die transformierte Zahl als String enthält
unsigned char *NameOfValuebox;                  // Name der Valuebox für Übertragung neuer Werte

int i=0;                                        // Laufvariable
int j=0;                                        // Laufvariable

volatile int plot_every_nth = 1;                // gibt an, wie viele Punkt beim Plotten ausgelassen werden

const int Lamella_Logger_Time_s = 1;            // gibt an, in welchen Abständen der Wert des reflektieren Strahls in .lam File abgespeichert wird (in [s]).
int counter_Lamella_Logger_steps;               // Steps, nach denen Zahlenwert in die .lam Datei geschrieben werden soll



#include "Measurement_Parameters.h"
#include "Laser_Control.h"                      // Funktionen zum Ansteuern des Lasers
#include "StepperMotor_Control.h"               // Funktionen zum Ansteuern des Schrittmotors
#include "NextionLCD_PlotParameters.h"          // Parameter für Plots
#include "NextionLCD_Communication.h"           // Funktionen für Kommunikation mit dem LCD-Display
#include "NextionLCD_PlotLiveData.h"            // Funktionen für Plots im Fenster "LiveData"
#include "NextionLCD_PlotScaledData.h"          // Funktionen für Plots im Fenster "ScaledData"
#include "NextionLCD_PlotSettings.h"            // Funktionen für Plots im Fenster "Settings"
#include "Photodiode_Data.h"                    // Funktionen zum Auslesen der Werte der Photodiode
#include "Measurement_Setup.h"                  // Setup der Messung
#include "CY_ISR_Interrupt.h"                   // Interrupt-Funktion zum Einlesen der Slider-Werte
#include "CYISR_Timer1_Interrupt.h"             // Timerfunktion von Timer1
#include "DataLogger.h"                         // Loggen der ADC-Werte
    
float Bin_Number[NumberOfBins];                 // Arrays für Wahrscheinlichkeiten definieren; Darstellung in "ScaledData"
float Bin_Lifetime_Probability[NumberOfBins];   // Arrays für Wahrscheinlichkeiten definieren; Darstellung in "ScaledData"


int main()
{
    // INITIALISLISIERUNG 
    
    // char str[80];

    // sprintf(str, "Value of Pi = %f", M_PI);
    // puts(str);
    
    // Enable global interrupts -> wichtig: sonst keine Interaktion Touchscreen <-> PSOC
    CyGlobalIntEnable; 

    // Status-LED an Pin 2.1 an -> zeigt, dass Initialisierung gestartet
    InitLED_ON;
    
    // Stewpper und Lasr Test
    // TestRotationMove(900);
    
    /* Start the TIA component */
    TIA_1_Start();
    /* Set the Resistive feedback to 40k ohms */
    // TIA_1_SetResFB(TIA_1_RES_FEEDBACK_40K);
    /* Set the capacitive feedback to 3.3pF */
    // TIA_1_SetCapFB(TIA_1_CAP_FEEDBACK_3_3PF);
    // Ergebnisarray initialisieren;
    
    PGA_Photo_Start();
    
    for (i=0;i<1000;i++)
    {
        Number[i] = 0;
        Lifetime[i]= 0;
    }
    
    // Wahrscheinlichkeitsarray initialisieren
    for (i=0;i<NumberOfBins;i++)
    {
        Bin_Number[i] = i+1;
        Bin_Lifetime_Probability[i]= 0;
    }
        
    // EEPROM starten
    Emul_EEPROM_Start();

   
    // Initialize file system --> SD-Karte
    FS_Init();
    
    // Nextion TFT Initialisieren und "Home" als Startseite anzeigen
    Init_NextionTFT();

    // Interrupt-Funktion für UART_TFT starten bzw. dem Interrupt eine Funktion zuweisen
    Interr_TFT_StartEx(UART_TFT_InterruptFunction);
    // Interrupt von Timer1, also "Timer1_Function" mit "seiner" mit Funktion,"Timer1_Interrupt_Function"
    Timer1_Function_StartEx(Timer1_Interrupt_Function);

    // Timer starten
    Timer1_Start();
    
    // ADC bzw. Analog-Digital-Konverter Initialisieren
    Analog_Digital_Converter_Start();
    Analog_Digital_Converter_StartConvert();
   
//    // Starten des USB-Interface
//    USBUART_PC_Start(0,USBUART_PC_5V_OPERATION);    
//    // Konfiguration vom PC lesen
//    while(USBUART_PC_GetConfiguration() == 0);    
//    // Initialisierung des CDC-Kommunkations-Interface
//    USBUART_PC_CDC_Init();
    // Initialisierung des UART für Memory-Stick
    //UART_Memory_Start();
    
    // Test-LEDs
    LED_slider_val_sent_Write(slider_val_sent);
    LED_slider_val_received_Write(slider_val_received);
    LED_Measurement_running_Write(1);    
    
    UART_TFT_PutString((char*)"page Home");
    
    CyDelay(300);
        
    // Status-LED an Pin 2.1 aus -> zeigt, dass Initialisierung beendet
    InitLED_OFF; 
    // MoveToHomePosition(); 

    // Dummy-Messergenisse für Testphase (Schreiben auf SD-Karte)
    // volatile int Number[] =  { 1, 2, 3, 4, 5, 6, 7, 8};
    // volatile int Lifetime[] = { 42, 534, 244, 213, 422, 33, 767, 13123};
    // NumberOfMeasurements = 8;
    
    //
    // !!! für die folgenden 3 größen:
    //     der Faktor "10" stammt von der Umrechnung des 100ms Counters, der für die Messung 
    //     verantwortlich auf Sekunden
    //
    // "Gnadenfrist" für Lamelle; unterhalb dieser Zeit wird Lamelle als anwesend angenommen,
    // auch wenn das Signal unterhalb des festgelegten Grenzwerts ist.
    counter_Lamella_Relaxation_steps = (int)Lamella_Relaxation_Time_s*SampligCountsPerSecond;
    // Maximal erlaubte Lebenszeit definieren
    counter_Maximum_Lamella_Time_steps = (int)(Maximum_Lamella_Time_h*3600*SampligCountsPerSecond);
    // Anzahl der Schritte, die das Signal den Schwellwert unterschreiten muss
    counter_Rupture_Confirmation_Target = Rupture_Confirmation_Time_s*SampligCountsPerSecond;
    // Counts festlegen, nach denen oberhalb einer gewissen Grenzzeit in das log-File geschrieben wird
    counter_Lamella_Logger_steps = Lamella_Logger_Time_s*SampligCountsPerSecond;
    
    // Motor initialisieren
    Init_Stepper();
    
  
    // ##################################################
    // ##################################################
    // ##################################################
    //
    // Testzwecke
//    int k;
//    for (k=0; k <10; k++)
//    {
//        // LED togglen, zum Test, ob der Timer läuft
//        Pin_LED_Write(!Pin_LED_Read()); 
//        // LED togglen, zum Test, ob der Timer läuft
//        CyDelay(40);
//        Pin_LED_Write(!Pin_LED_Read()); 
//        // LED togglen, zum Test, ob der Timer läuft
//        CyDelay(40);
//    }

//    while (1)
//    {
//        MoveTo(3200, RIGHT);  // = volle Umdrehung im 16tel-Schritt Betrieb
//        CyDelay(1000);
//        MoveTo(3200, LEFT);  // = volle Umdrehung im 16tel-Schritt Betrieb
//        CyDelay(1000);
//    }
    // so startet eine "Messung" unmittelbar nach dem Programmieren --> schneller Test mit wenig Wiederholungen.
    //Measurement_running = 1;
    //NumberOfMeasurements = 2;
    //
    // ##################################################
    // ##################################################
    // ##################################################

    // Datei für Logger öffnen; der Name ist bereits nach dem Einschalten festgelegt
    OpenLoggerFile();
    
    // MAINLOOP
    for(;;)
    {       

    // ADC einlesen
    // Warten bis der AD-Wandler fertig ist
    Analog_Digital_Converter_IsEndConversion(Analog_Digital_Converter_WAIT_FOR_RESULT);
    // Ergebnis einlesen und als ADC_value abspeichern
    // 4095 entsprechen 2.048V
    ADC_value = Analog_Digital_Converter_GetResult16();   
        
    LED_slider_val_sent_Write(slider_val_sent);
    LED_slider_val_received_Write(slider_val_received);
    LED_Measurement_running_Write(Measurement_running);

    if (timerflag100ms)
    {
        timerflag100ms = 0;
        // Wenn Messung noch nicht gestartet wurde
        if (Measurement_running == 1)
        {
            
            // LED togglen, zum Test, ob der Timer läuft
            Pin_LED_Write(!Pin_LED_Read()); 
            
            // ADC einlesen
            // Warten bis der AD-Wandler fertig ist
            //Analog_Digital_Converter_IsEndConversion(Analog_Digital_Converter_WAIT_FOR_RESULT);
            // Ergebnis einlesen und als ADC_value abspeichern
            // 4095 entsprechen 2.048V
            //ADC_value = Analog_Digital_Converter_GetResult16();    
            
            // ##################################################
            // ##################################################
            // ##################################################
            // !!!! NEUER LOGGER !!!!!!!!
            //
            // Daten für jede einzelne Lamelle loggen loggen
            // 
            // Testwert des ADC
//            ADC_value = 1000;
////            // Test, damit Abbruch der Messung nach 3s
//            if (counter_Timer1_steps > 1800*10)
//            {
//                ADC_value = 0;
//            } 
            // ##################################################
            // ##################################################
            // ##################################################
            
            //
            // Name der Logger-Datei setzen und sie öffnen
            //
//            if (bool_NewLamellaFileNameSet == 0)
//            {
//                // Pointer auf die Adresse des letzten (= 4.) Eintrag des EEPROM-Arrays setzen
//                ptr = &eepromArray[3];
//                // Dereferenzieren des Pointers -> Wert, auf den "ptr" zeigt in "eeprom_cnt" abspeichern
//                eeprom_cnt = *ptr;
//                // Name der Datei festlegen, in die Reflektivitäten der aktuellen Lamelle geschrieben werden sollen
//                sprintf((char*)FileNameCurrentLamellaFile, "%d-%d.lam", eeprom_cnt, (int)(counter_Lamella_Number+1)); 
//                UART_TFT_PutString("t0.txt=\""); 
//                UART_TFT_PutString((char*)FileNameCurrentLamellaFile);
//                UART_TFT_PutString((char*)"\"");
//                UART_TFT_PutChar(0xFF);
//                UART_TFT_PutChar(0xFF);  
//                UART_TFT_PutChar(0xFF);
//                // Logger-File zum Schreiben öffnen
//                FileNameLogger = FS_FOpen(FileNameCurrentLamellaFile, "w");  
//                int OpeningTry = 0;
//                while (FileNameLogger == 0)
//                {
//                	OpeningTry += 1;
//                	// neuen Wert setzen
//                	UART_TFT_PutString((char*)"e_no_meas.val=");
//                	sprintf(num_str, "%d", OpeningTry);
//                	UART_TFT_PutString(num_str);
//                	// Anfrage absenden
//                	UART_TFT_PutChar(0xFF);
//                	UART_TFT_PutChar(0xFF);  
//                	UART_TFT_PutChar(0xFF);  
//                	
//                	// Logger-File zum Schreiben öffnen
//                	FileNameLogger = FS_FOpen(FileNameCurrentLamellaFile, "w");
//                	
//                	// Maximal 100 Öffnungsversuche
//                	if (OpeningTry == 100)
//                	{
//                		break;
//                	}
//                }
//                CyDelay(50);
//
//                // Sicherstellen, dass der Dateiname nur einmal geschrieben wird
//                bool_NewLamellaFileNameSet = 1;
//            }
            //
            // Abspeichern von Zeit und Reflektivität im geöffneteb ".lam"-File mit passendem Namen
            // wird nur einmal geöffnet, wenn der Dateiname gesetzt wird; geschlossen, wenn nächste
            // Lamelle oder Messung gestoppt
            //
            IntensityLogger_ONE_Channel(counter_Timer1_steps, ADC_value);        
            
            
            // Wenn maximal erlaubte Lebensdauer überschritten ist, so tun als ob Lamelle gerissen ist,
            // den Wert des ADC auf "0" setzen
            if (counter_Timer1_steps >= counter_Maximum_Lamella_Time_steps)
            {
                ADC_value = 0;
                // Abriss der Lamelle bestätigt
                // bool_Rupture_Confirmed = 1;
            }

            // Wenn ADC-Wert oberhalb des benötigten Grenzwertes ist -> Lamelle noch da
            if (ADC_value > PresenceThreshold)
            {
                // Counter für Anwesenheit der Lamelle inkrementieren
                counter_Timer1_steps = counter_Timer1_steps + 1;
                
                // Lamelle ist nicht(!) abgerissen, sobald wieder einmal Wert oberhalb des Grenzwerts ist
                bool_Rupture_Confirmed = 0;
                // Zähler für Lamellenabriss zurücksetzen
                counter_Rupture_Confirmation = 0;
                
                // Testausgabe des Aktuellen Zeitzählerstands in eine Textbox
//////                UART_TFT_PutString((char*)"t1.txt=");
//////                UART_TFT_PutString((char*)"\"");
//////                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
//////                itoa((int)counter_Timer1_steps, num_str, 10);
//////                UART_TFT_PutString(num_str);
//////                UART_TFT_PutString((char*)"\"");
//////                // Ende der Eingabe markieren
//////                UART_TFT_PutChar(0xff);
//////                UART_TFT_PutChar(0xff);
//////                UART_TFT_PutChar(0xff); 
            }
            // Wenn der Wert zwar unterhalb dem benötigten Grenzwert ist, aber gleichzeitig die Lamelle
            // noch nich relaxiert ist, also noch einschwingen muss;
            else if ((counter_Timer1_steps < counter_Lamella_Relaxation_steps) & (bool_Rupture_Confirmed == 0))
            {
                // so tun, also ob das Signal schon da wäre und einfach den Counter inkrementieren
                // Counter für Anwesenheit der Lamelle inkrementieren
                counter_Timer1_steps = counter_Timer1_steps + 1; 
                // Lamelle ist nicht(!) abgerissen, sobald wieder einmal Wert oberhalb des Grenzwerts ist
                bool_Rupture_Confirmed = 0;
                // Zähler für Lamellenabriss zurücksetzen
                counter_Rupture_Confirmation = 0;
            }
            // Wenn ADC-Wert zwar unterhalb des benötigten Grenzwertes aber und Lamellenabriss noch nicht bestätigt -> Lamelle im Übergangszustand
            else if ((ADC_value < PresenceThreshold) & (bool_Rupture_Confirmed == 0) & (counter_Timer1_steps >= counter_Lamella_Relaxation_steps))
            {
                // so tun, also ob das Signal schon da wäre und einfach den Counter inkrementieren
                // Counter für Anwesenheit der Lamelle inkrementieren
                counter_Timer1_steps = counter_Timer1_steps + 1;   
                // Zähler für Lamellenabriss hochzählen
                counter_Rupture_Confirmation = counter_Rupture_Confirmation + 1;
                if (counter_Rupture_Confirmation == counter_Rupture_Confirmation_Target)
                {
                    // Abriss der Lamelle bestätigt
                    bool_Rupture_Confirmed = 1;
                    // Counter für Lebenszeit der Lamelle auf den Wert bei der ersten Grenzwert-Unterschreitung setzen
                    counter_Timer1_steps = counter_Timer1_steps - counter_Rupture_Confirmation_Target;
                }
            }
            // Wenn ADC-Wert unterhalb des benötigten Grenzwertes ist und Lamellenabriss bestätigt -> momentane LAMELLE ABGERISSEN!!!
            else if ((ADC_value < PresenceThreshold) & (bool_Rupture_Confirmed == 1))
            {
                // nächste Lamelle ist nicht(!) abgerissen
                bool_Rupture_Confirmed = 0;
                // Zähler für Lamellenabriss zurücksetzen
                counter_Rupture_Confirmation = 0;
                // Momentanes File des Datenloggers schliessen
                CloseLoggerFile();
                // An Datenlogger übergeben, dass der Name für die als nächste abgeholte Lamelle noch nicht gesetzt ist
                bool_NewLamellaFileNameSet = 0;                
                
                // gerade erhaltenes Ergebnis im Ergebnisarray speichern bzw. ablegen
                if (present_Result_saved == 0)
                {
                    // Bool, die bewirkt, dass der Wert nur einmal(!) in Ergebnisarray geschriebn wird
                    present_Result_saved = 1;
                    
                    // Boolean, die anzeigt, dass arrays mit dem neu erhaltenen Wert noch nicht auf USB gespeichert
                    STI100_present_results_saved = 0;
                    
                    // Nummer und Lebenszeit der gerade untersuchten Lamelle im Ergebnisarray abspeichern
                    Number[counter_Lamella_Number] = counter_Lamella_Number + 1;
                    Lifetime[counter_Lamella_Number] = counter_Timer1_steps;            // ein Step = 100ms Lebenszeit
                    
                    // Testen, ob bisherige Maximal-Lebensdauer überschritten wurde; Lifetime_max "on the fly" bestimmen
                    if (Lifetime_max < counter_Timer1_steps)
                    {
                        Lifetime_max = counter_Timer1_steps;
                        if (menustate == 2)
                        {
                            UART_TFT_PutString((char*)"ref LiveData");
                            // Ende der Eingabe markieren
                            UART_TFT_PutChar(0xff);
                            UART_TFT_PutChar(0xff);
                            UART_TFT_PutChar(0xff);
                        } 
                    } 
                    
                    // Umskalierte Darstellung muss bei jedem neuen Wert aktualisiert werden
                    UART_TFT_PutString((char*)"ref ScaledData");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    
                    // Bool setzten, die angibt, dass man Plot wieder aktualisieren soll
                    present_LiveData_plot_refreshed = 0;
                    current_RescaledData_plot_refreshed = 0;
                    
////                    // Testausgabe
////                    UART_TFT_PutString((char*)"tl0.txt=");
////                    UART_TFT_PutString((char*)"\"Messung Nr: ");
////                    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
////                    itoa((int)Number[counter_Lamella_Number], num_str, 10);
////                    UART_TFT_PutString(num_str);
////                    UART_TFT_PutString((char*)"\"");
////                    // Ende der Eingabe markieren
////                    UART_TFT_PutChar(0xff);
////                    UART_TFT_PutChar(0xff);
////                    UART_TFT_PutChar(0xff); 
                    
                    // Counter inkrementieren bzw. zurücksetzen
                    counter_Lamella_Number = counter_Lamella_Number + 1;
                    counter_Timer1_steps = 0; 
                    
                    // Flag, dass neue Lamelle ausgebildet werden soll
                    new_pickup_initialized = 1;
                }
                
                // Wenn Anzahl benötigter Messungen erreicht
                if (counter_Lamella_Number == NumberOfMeasurements)
                {
                    // Messung stoppen
                    Measurement_running = 0;
                                        
                    // Counter zurücksetzen
                    counter_Lamella_Number = NumberOfMeasurements;
                    counter_Timer1_steps = 0; 
                    
                    // Pickup-Position anfahren
                    MoveToHomePosition();
                    
                    // Ins Hauptmenü wechseln
                    menustate = 0;
                    
                    // Erscheinungsbild des Buttons anpassen
                    UART_TFT_PutString((char*)"page Home");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff); 
                    UART_TFT_PutString((char*)"b_measure.txt=\"Start Measurement\"");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff); 
                    UART_TFT_PutString((char*)"b_measure.bco=1024");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutString((char*)"ref Home");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff); 
                    UART_TFT_PutString((char*)"vis slider,1");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    
                    // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten
                    present_LiveData_plot_refreshed = 0;                
                    current_RescaledData_plot_refreshed = 0;                    
                    
                    // Selbstständiges Abspeichern am Ende der Messung
                    // Anfrage auf Speichern vortäuschen ( = so tun, als ob man
                    // auf die Export und Speicher Taste drücken würde)
                    // "auf Export drücken"
                    menustate = 4;
                    // " auf Speichern drücken"
                    STI100_write_requested = 1;
                    CyDelay(100);
                    UART_TFT_PutString((char*)"page Export");
                    // Ende der Eingabe markieren
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff);
                    UART_TFT_PutChar(0xff); 
                    
                }
                // sonst neue Lamelle holen
                else
                {
                    // Anzeige, dass gerade eine neue Lamelle abgeholt wird -> Timer Flag "timerflag100ms" kann im(!) Timer nicht auf auf high gesetzt werden
                    new_pickup_initialized = 1;
                    
                    // Pickup-Position anfahren
                    MoveToHomePosition();
                    // Warten, dass sich die Lamelle ausbildet
                    CyDelay(LamellaFormationTime_ms);
                    // Vor Beginn der Messung Zieldatei für Reflektivität, *.lam, erstellen
                    OpenLoggerFile();
                    // Sampling-Position anfahren
                    MoveToSamplingPosition();
                    
                    // Anzeige, dass Sampling Position wieder erreicht ist -> Timer Flag "timerflag100ms" kann wieder high werden
                    new_pickup_initialized = 0;
                    
                    // -> dann sollte ADC-Wert wieder ausreichend hoch sein; hier wird das "simuliert"
                    // zum Test -> Lamelle wieder ausbilden bedeutet Intensität oberhalb eines Grenzwertes,
                    // im Experiment sollte(!) das der Fall sein, wenn Sampling Position wieder erreicht ist.
                    i = 0;
                    
                    present_Result_saved = 0;                      // erlaubt, dass nächster Messwert in Ergebnis-Array geschrieben wird
                }
            }
            
//            Nextion_Send_Value_To_Valuebox ("int_now", ADC_value);
                
            // Momentane Intensität an Valuebox übertragen
            UART_TFT_PutString((char*)"int_now.val=");
            // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
            itoa(ADC_value, num_str, 10);
            UART_TFT_PutString((char*)num_str);
            // Ende der Eingabe markieren
            UART_TFT_PutChar(0xff);
            UART_TFT_PutChar(0xff);
            UART_TFT_PutChar(0xff); 
            
                
        }            
    }  
    
        
    // Switch case Umgebung je nach Hauptseite auf der man sich befindet, wird von Interrupt "CY_ISR_Interrupt" aus abgefragt
    switch (menustate)
    {
        
        
        // Seite "Home"
        case 0:  
        
//            if (Measurement_running == 1)
//            {
//                // Fehlerbehandlung
//                if (FileNameLogger == 0)
//                {
//                	// Fehler
//                	UART_TFT_PutString("tStat.txt=\"Error\"");
//                	UART_TFT_PutChar(0xFF);
//                	UART_TFT_PutChar(0xFF);  
//                	UART_TFT_PutChar(0xFF); 
//                }
//                else
//                {
//                	// kein Fehler
//                	UART_TFT_PutString("tStat.txt=\"OK!\"");
//                	UART_TFT_PutChar(0xFF);
//                	UART_TFT_PutChar(0xFF);  
//                	UART_TFT_PutChar(0xFF); 
//                }
//            }
//            else
//            {
//                // kein Fehler
//            	UART_TFT_PutString("tStat.txt=\"Ready.\"");
//            	UART_TFT_PutChar(0xFF);
//            	UART_TFT_PutChar(0xFF);  
//            	UART_TFT_PutChar(0xFF); 
//            }
           
            if (slider_val_received == 1)
            {
                slider_val_received = 0;
                slider_val_sent = 0;
                NumberOfMeasurements = Nextion_NumberOfMeasurementsFromSlider();
                
                // So werden maximal(!) "NumberOfShowResults-1" Punkte dargestellt
                plot_every_nth = NumberOfMeasurements/NumberOfShowResults + 1;
            }

            // Slider-Wert setzen
            Nextion_SendProgressbarValue((unsigned int)(100*counter_Lamella_Number/NumberOfMeasurements));
            
            // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten
            present_LiveData_plot_refreshed = 0;                
            current_RescaledData_plot_refreshed = 0;
            
            break;

        
        // Seite "Settings"
        case 1: 
            
            // Laser an
            Laser_ON();            
            
            // Daten in Fenster "Settings" malen
            PointsToSettingsAxes((float)PresenceThreshold, (float)ReferenceThreshold, (float)ADC_value);            
            break;
            
            // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten
            present_LiveData_plot_refreshed = 0;                
            current_RescaledData_plot_refreshed = 0;

            // Laser aus
            Laser_OFF();
            
            
        // Seite "LiveData"
        case 2: 
            
            // Daten in Fenster "LiveData" malen
            if ((timerflag1000ms ==1) && (present_LiveData_plot_refreshed == 0))
            {
                // Maximalwert auf y-Achse
                UART_TFT_PutString((char*)"ymax_LiveData.val=");
                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
                itoa(Lifetime_max, num_str, 10);
                UART_TFT_PutString((char*)num_str);
                // Anfrage absenden
                UART_TFT_PutChar(0xFF);
                UART_TFT_PutChar(0xFF);  
                UART_TFT_PutChar(0xFF);
                // Maximalwert auf x-Achse
                UART_TFT_PutString((char*)"xmax_LiveData.val=");
                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
                itoa(NumberOfMeasurements, num_str, 10);
                UART_TFT_PutString((char*)num_str);
                // Anfrage absenden
                UART_TFT_PutChar(0xFF);
                UART_TFT_PutChar(0xFF);  
                UART_TFT_PutChar(0xFF);
                
                present_LiveData_plot_refreshed = 1;
                //for (j=0; j<NumberOfMeasurements; j=j+plot_every_nth)
                for (j=0; j<=counter_Lamella_Number; j=j+plot_every_nth)                
                {
                    // sonst fängt der Plot immer links von der Achse an
                    if (Number[j]>0)
                    {
                        PointToLiveDataAxes((float)1.0*Number[j], (float)1.0*Lifetime[j]);
                    }                  
                } 
                
                // Slider-Wert setzen
                Nextion_SendProgressbarValue((unsigned int)(100*counter_Lamella_Number/NumberOfMeasurements));
            }
            
            // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten              
            current_RescaledData_plot_refreshed = 0;

           
            break;
            
            
        // Seite "ScaledData"
        case 3:  
      
            
            // Umskalierte Daten in Fenster "ScaledData" malen   

            if ((timerflag1000ms ==1) && (current_RescaledData_plot_refreshed == 0))
            {                    
                // Ticks in Plot setzen
                //Nextion_Send_Value_To_Valuebox((char*)"xmax_Scaled",Lifetime_max);
                UART_TFT_PutString((char*)"xmax_Scaled.val=");
                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
                itoa(Lifetime_max, num_str, 10);
                UART_TFT_PutString((char*)num_str);
                // Anfrage absenden
                UART_TFT_PutChar(0xFF);
                UART_TFT_PutChar(0xFF);  
                UART_TFT_PutChar(0xFF);
            
                timerflag1000ms = 0;
                            
                current_RescaledData_plot_refreshed = 1;
                                    
                // Bin-Breite berechnen
                WidthOfBin = Lifetime_max/NumberOfBins;
                
                // Betrachtung für jedes der Bins
                for (j=0;j<NumberOfBins;j++)
                {
                    // Anzahl der Messungen mit Lebenszeit unterhalb der Grenze zum nächsten Bin bestimmen
                    int cnt = 0;
                    float test_float = 0;
                    for (i=0;i<counter_Lamella_Number;i++)
                    {
                        if (Lifetime[i]<=1.0*(j+1)*WidthOfBin+1)
                        {
                            cnt = cnt + 1;
                        }
                    }
                    test_float = (1.0*cnt)/(1.0*counter_Lamella_Number);
                    Bin_Lifetime_Probability[j] = 100*(1.0-test_float);
                }
                
                // Erster Punkt der Darstellung ist immer 100% Lebenswahrscheinlichkeit bei 0 Sekunden
                PointToScaledDataAxes(0.0, 100.0);
                
                // Reskalierte Daten Malen
                for (j=0; j<NumberOfBins; j++)
                {
                    PointToScaledDataAxes(Bin_Number[j], Bin_Lifetime_Probability[j]);
                } 
                
                // Slider-Wert setzen
                Nextion_SendProgressbarValue((unsigned int)(100*counter_Lamella_Number/NumberOfMeasurements));
            }
            
            // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten
            present_LiveData_plot_refreshed = 0;                
          
            break;  
            
        // Seite "Export"
        case 4:          
  
            // Booleans so setzten, dass Plots wieder aktualisiert werden nach Wechsel der Seiten
            present_LiveData_plot_refreshed = 0;                
            current_RescaledData_plot_refreshed = 0;
            
            // Pointer auf die Adresse des letzten (= 4.) Eintrag des EEPROM-Arrays setzen
            ptr = &eepromArray[3];
            // Dereferenzieren des Pointers -> Wert, auf den "ptr" zeigt in "eeprom_cnt" abspeichern
            eeprom_cnt = *ptr;
////            // Pointer auf die Adresse des letzten (= 3.) Eintrag des EEPROM-Arrays setzen
////            ptr = &eepromArray[2];
////            // Dereferenzieren des Pointers -> Wert, auf den "ptr" zeigt in "eeprom_cnt" abspeichern
////            eeprom_cnt = eeprom_cnt+16*(*ptr);
            
            
            if ((STI100_write_requested == 1) && (STI100_writing ==0))
            {
                                
                // Angeben, dass der USB-Stick gerade beschrieben wird
                STI100_writing = 1;
                
                // Kommunikation auf Display, dass Stick beschrieben wird
                // !!! TODO !!!
                // zusätzliches Textfeld einfügen
                                
                // Puffer für Dateiname
                char buffer_filename[30];
                // gesamten String zur Übergabe für Dateinamen zusammenbauen
                // z.B. "Nr-0023.txt"
                // Dummy-Dateiname für Testphase
                // eeprom_cnt = 111;
                sprintf((char*)buffer_filename, "Nr-%04d.txt", eeprom_cnt);     
            
                // File öffnen
                FS_FILE *pFile;
                pFile = FS_FOpen(buffer_filename, "w");
                CyDelay(100);
                
                // Kopfzeile schreiben
                char HeaderLine[] = "NoMeasurement_au,LifeTime_s\n";
                if(0 != FS_Write(pFile, HeaderLine, strlen(HeaderLine))) 
                {
                    // OK
                }
                else
                {
                    // Error
                    break;
                } 
                    
                // für jeden Eintrag der Arrays eine Ergebniszeile schreiben
                int j = 0;   
                
                for (j=0;j<NumberOfMeasurements;j++)
                {
                    // Erzeuegen der Ausgabe der nächsten Zeile in einem Puffer
                    char buffer_nextline[30];
           
                    // String erzeugen -> z.B. "0001,324324.2" 
                    // Umrechnung countersteps -> Sekunden
                    float Lifetime_s;
                    Lifetime_s = 1.0*Lifetime[j]/10;
                    // Formatierten String erzeugen und in "buffer_nextline" abspeichern
                    // floating point geht warum auch immer nicht!!!
                    // sprintf((char*)buffer_nextline, "%04d,%d\n",Number[j],Lifetime[j]/10);
                    // Ergebniszeile: Nummer der Messung und Lebenszeit der zugehörigen Lamelle in [s].
                    sprintf((char*)buffer_nextline, "%04d,%0.1f\n", Number[j], Lifetime_s);
                    
                    // gepufferte Zeile in Ergebnisdatei schreiben
                    if(0 != FS_Write(pFile, buffer_nextline, strlen(buffer_nextline))) 
                    {
                        // OK
                    }
                    else
                    {
                        // Error
                        break;
                    } 
                    // Slider setzen
                    Nextion_SendSaveProgressbarValue((j/(NumberOfMeasurements-1))); 
                    //CyDelay(10);
                }
                
                // Schliessen der Datei, in die geschrieben wurde
                if(0 == FS_FClose(pFile))
                {
                    // alles ok
                    CyDelay(200);
                }
                else
                {
                   // Fehler
                   break;
                } 
            
                // Angeben, dass letzte Schreibanfrage gearde abgearbeitet wurde.
                STI100_write_requested = 0;                    
                
                // Boolean, die angibt, dass Ergebnisse auf USB gespeichert wurden
                STI100_present_results_saved = 1;
                
                // Angeben, dass Beschreiben des USB-Sticks gerade beendet wurde
                STI100_writing = 0;
                Nextion_HideButtonSaveToUSB();
                
                // EEPROM Counter bei jeder Speicherungsanfrage inkrementieren
                eeprom_cnt++;
                // neuen Wert des Counters in das letzte Byte des EEPROM schreiben; fängt nach 256 wieder bei 0 an
                status = Emul_EEPROM_Write(&eeprom_cnt,&eepromArray[3],1u);
            } 
            
            // Wechsel zwischen saved und unsaved Icon
            if (STI100_present_results_saved == 0)
            {
                //Nextion_SendSaveProgressbarValue(0);
                // Momentanen Wert des EEPROM-Counters an Valuebox übertragen
                //Nextion_Send_Value_To_Valuebox ("no_save", eeprom_cnt);
                UART_TFT_PutString((char*)"no_save.val=");
                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
                itoa(eeprom_cnt, num_str, 10);
                UART_TFT_PutString((char*)num_str);
                // Ende der Eingabe markieren
                UART_TFT_PutChar(0xff);
                UART_TFT_PutChar(0xff);
                UART_TFT_PutChar(0xff);
            }
            else if (STI100_present_results_saved == 1)
            {
                Nextion_SendSaveProgressbarValue(100);
                Nextion_HideButtonSaveToUSB();
                // Um eins erniedrigten Wert des EEPROM-Counters an Valuebox übertragen
                //Nextion_Send_Value_To_Valuebox ("no_save", eeprom_cnt);
                UART_TFT_PutString((char*)"no_save.val=");
                // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
                itoa(eeprom_cnt-1, num_str, 10);
                UART_TFT_PutString((char*)num_str);
                // Ende der Eingabe markieren
                UART_TFT_PutChar(0xff);
                UART_TFT_PutChar(0xff);
                UART_TFT_PutChar(0xff);
            }
            
            
            break; 
            
        // Default case -> break
        default:
            break;
        }    
    }
}

/* [] END OF FILE */
