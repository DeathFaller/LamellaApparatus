#ifndef NEXTIONLCD_PLOTSCALEDDATA_H
#define NEXTIONLCD_PLOTSCALEDDATA_H    

#include <project.h>
#include <math.h>
#include <stdlib.h>

//
// Achtung!!! #ifndef #define #endif-Konstruktion zur Vermeidung von doppelten Definitione
//
#include "NextionLCD_Communication.h"                // Funktionen für Kommunikation mit dem LCD-Display
#include "Measurement_Setup.h"
#include "NextionLCD_PlotParameters.h"

//
// Messpunkt in DataLive einzeichnen
//
void PointToScaledDataAxes (float x, float y)
{
    // Hilfsvariable mit 20 Zeichen
    char num_str[20];
    
    // Umskalieren des Wertes, sodass er in Zeichenfläche liegt
    x = Nextion_plot_ScaledData_x+Nextion_plot_ScaledData_w*(x/(1.0*NumberOfBins));         // Plot-Fenster im Bereich [0,NumberOfBins]
    y = Nextion_plot_ScaledData_y+Nextion_plot_ScaledData_h*(1-(1.0*y/100));                // Plot-Fenster im Bereich [0,100]
    
    // Zielstring "cir x-Koordinate,y-Koordinate,Radius,Farbe"
    UART_TFT_PutString("cirs ");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(x, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa((int)y, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Mark Size übertragen
    itoa(Settings_MarkSize, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Farbe übertragen
    UART_TFT_PutString("GREEN");
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);            
}

#endif // NEXTIONLCD_PLOTSCALEDDATA_H