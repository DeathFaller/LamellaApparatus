#ifndef MEASUREMENT_PARAMETERS_H
#define MEASUREMENT_PARAMETERS_H
    
// Grenzwert für Anwesenheit der Lamelle
#define PresenceThreshold 110 //90 -> ! bevor Umstelllung auf Öffnen mit OpenLoggerFile() war Grenzwert 90 in Ordnung -> Hardwareproblem?
#define ReferenceThreshold 3800

const float Maximum_Lamella_Time_h = 0.75;          // Maximal "erlaubte" Lebenszeit einer Lamelle in [h], danach wird neue ausgebildet
const int Lamella_Relaxation_Time_s = 1;            // Zeit, die der Lamelle gegeben wird, bis sich konstantes Signal einstellt in s
const float Rupture_Confirmation_Time_s = 0.5;      // Zeit, die das Signal, den Grenzwert unterschreiten muss, damit Lamelle als gerissen zählt

const int SampligCountsPerSecond = 10;              // Anzahl der Datenpunkte, die pro Sekunde gesamplet werden == Frequenz des Messtimers bzw. -Interrupts

const int LamellaFormationTime_ms = 2500;           // Zeit im ms, die vom Anfahren der Home-Position bis zum Ausbilden der nächsten Lamelle vergehen soll

#endif // MEASUREMENT_PARAMETERS_H    