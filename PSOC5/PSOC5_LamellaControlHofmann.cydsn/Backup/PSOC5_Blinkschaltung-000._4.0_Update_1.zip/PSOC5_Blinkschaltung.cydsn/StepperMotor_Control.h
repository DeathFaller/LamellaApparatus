// "Include-Guard" für "StepperMotor_Control.h"
#ifndef STEPPERMOTOR_CONTROL_H
#define STEPPERMOTOR_CONTROL_H

#include <project.h>
#include <math.h>

#include "Laser_Control.h"
#include "Measurement_Parameters.h"

#define RIGHT 1
#define LEFT -1

// Parameter der Funktionen, die mit Schrittmotor zusammenhängen
static int const StepsDifferenceHomeSampling = 800;               // mit 1.8° / Step Motor -> 90°/1.8*16
static int const StepsOneStepSettings = 4;                		  // "einen" Schritt in Settings mit Buttons "+" und "-"

double f_max_Stepper;
double sig_shift_Stepper;
double sig_raise_Stepper;

//
// Initialisierungen für Schrittmotor zur Kontrolle der Lamellenposition
//
void Init_Stepper (void)
{
    // Werte der Motorparameter setzen (-> Verwendung in "MoveTo" verwendet)
    // Maximale Frequenz
    f_max_Stepper = 700;
    // Verschiebung des Sigmoids
    sig_shift_Stepper = -100;                   // höherere Wert -> höherere Frequenz zu Beginn
    // Anstieg des Sigmoids
    sig_raise_Stepper = 10;                     // höherer Wert -> schnellerer Anstieg
    
    // Betriebsart des Motors festlegen
    Pin_StepperMS1_Write(0); 	                // => 16tel-Schritt
    Pin_StepperMS2_Write(0);    
    Pin_StepperMS3_Write(1);   
    /*
    MODE0 	MODE1 	MODE2 	Microstepping
    0 	    0 	    0 	    Vollschritt
    1 	    0 	    0 	    Halbschritt
    0 	    1 	    1 	    1/4 Schritt
    1 	    1 	    0 	    1/8 Schritt
    0 	    0 	    1 	    1/16 Schritt        x => momentan ausgewählt 
    1 	    0 	    1 	    1/32 Schritt
    0 	    1 	    1 	    1/32 Schritt
    1 	    1 	    1 	    1/32 Schritt        
    */	
    
    // ENABLE -> Enable Stepper-Motor an
    Pin_StepperEN_Write(0); 
    // SLEEP -> Motor in Schlafzustand setzen -> keine Leistungsaufnahme
    Pin_StepperSLEEP_Write(0);
    // SLEEP -> Motor "aufwecken" -> Leistungsaufnahme
    Pin_StepperSLEEP_Write(1);
    // RESET -> nicht(!) resetten
    Pin_StepperRES_Write(1);
    
}


//
// Bewegen des Stepper-Motors um "steps" Schritte in Richtung "dir"
//
void MoveTo (double steps, double dir)
{
	// Übergebene Steps müssen mit 2 Mulipliziert werden, da jeder 
	// Schritt 2 Flankenwechsel beeinhaltet
	steps = steps*2;
	
    // Maximale Frequenz
    double f_max;
    // Relative Frequenz [0, 1]
    double f_rel;
    // Inkrement der Anzufahrenden Schritte
    int i;
    // gerundete Dauer des Stepper-Zustands
    double t_StepperCLK;    
    // Verschiebung des Sigmoids
    double sig_shift;                   // höherere Wert -> höherere Frequenz zu Beginn
    // Anstieg des Sigmoids
    double sig_raise;                   // höherer Wert -> schnellerer Anstieg
    
    //
    // Parameterset für Motorkontrolle aus "MotorRamp.m"
    //   
    f_max = f_max_Stepper;
    sig_shift = sig_shift_Stepper;
    sig_raise = sig_raise_Stepper;
    
    
    // SLEEP -> Motor "aufwecken" -> Leistungsaufnahme
    Pin_StepperSLEEP_Write(1);
    
    // Richtung setzen
    //
    // Rechtsdrehung
    if (dir == RIGHT)
    {
        Pin_StepperDIR_Write(0);
    }
    // Linksdrehung
    else
    {
        Pin_StepperDIR_Write(1);
    }    
    
    // Für jeden der Schritte
    for (i = 0; i < steps; i = i + 1)
    {
        // Frequenz für Beschleunigungsteil
        if (i < steps/2)
        {       
            // Berechnung der Frequenz
            f_rel = 1/(1+exp(-1/(steps/sig_raise)*(i-steps/sig_shift))); 
            // Momentane Ausgabe der LED invertieren
            Pin_StepperCLK_Write(!Pin_StepperCLK_Read());
            // Anzeige LED-Togglen zum Test
            // Pin_LED_Write(!Pin_LED_Read());
            // ALT: // Wartezeit berechnen
            // ALT: t_StepperCLK = round(1000/(f_max*f_rel));
            // ALT: // Warten
            // ALT: CyDelay(t_StepperCLK);
            // Wartezeit in ms berechnen
            t_StepperCLK = 1000000/(f_max*f_rel);   
            // umrechnen in us
            CyDelayUs((uint16)(t_StepperCLK));           

        }        
        // Frequenz für Abbremsungsgungsteil
        else 
        {
            // Berechnung der Frequenz
            f_rel = (1 - 1/(1+exp(-1/(steps/sig_raise)*(i-steps+steps/sig_shift)))); 
            // Momentane Ausgabe der LED invertieren
            Pin_StepperCLK_Write(!Pin_StepperCLK_Read());
            // Anzeige LED-Togglen zum Test
            // Pin_LED_Write(!Pin_LED_Read());
            // ALT: // Wartezeit berechnen
            // ALT: t_StepperCLK = round(1000/(f_max*f_rel));
            // ALT: // Warten
            // ALT: CyDelay(t_StepperCLK);
            // Wartezeit in ms berechnen
            t_StepperCLK = 1000000/(f_max*f_rel);            
            // umrechnen in us
            CyDelayUs((uint16)(t_StepperCLK));           

        }  
    }
    // SLEEP -> Motor in Schlafzustand setzen -> keine Leistungsaufnahme
    // Pin_StepperSLEEP_Write(0); 
}

//
// Bewegen des Stepper-Motors um "steps" Schritte in Richtung "dir"
//
void MoveToWithConstSpeed (double steps, double dir)
{
	// Übergebene Steps müssen mit 2 Mulipliziert werden, da jeder 
	// Schritt 2 Flankenwechsel beeinhaltet
	steps = steps*2;
	
    // Inkrement der Anzufahrenden Schritte
    int i;
    // gerundete Dauer des Stepper-Zustands
    double t_StepperCLK;       
    
    // SLEEP -> Motor "aufwecken" -> Leistungsaufnahme
    Pin_StepperSLEEP_Write(1);
    
    // Richtung setzen
    //
    // Rechtsdrehung
    if (dir == RIGHT)
    {
        Pin_StepperDIR_Write(0);
    }
    // Linksdrehung
    else
    {
        Pin_StepperDIR_Write(1);
    }    
    
    // Für jeden der Schritte
    for (i = 0; i < steps; i = i + 1)
    {
        // Momentane Ausgabe der LED invertieren
        Pin_StepperCLK_Write(!Pin_StepperCLK_Read());
        t_StepperCLK = 27500; // [mus]
        CyDelayUs((uint16)(t_StepperCLK));     
    }
    // SLEEP -> Motor in Schlafzustand setzen -> keine Leistungsaufnahme
    // Pin_StepperSLEEP_Write(0); 
}

//
// Einzelschritt fahren zum Suchen der Referenz-Position
//
void MoveOneStep_Clockwise (void)
{
    MoveToWithConstSpeed(StepsOneStepSettings, -1);
}

//
// Einzelschritt fahren zum Suchen der Referenz-Position
//
void MoveOneStep_CounterClockwise (void)
{
    MoveToWithConstSpeed(StepsOneStepSettings, 1);
}

//
// Positionswechsel Home -> Sampling
//
void MoveToSamplingPosition (void)
{
    MoveTo(StepsDifferenceHomeSampling, -1);
}


//
// Positionswechsel Home -> Sampling
//
void MoveToHomePosition (void)
{
    MoveTo(StepsDifferenceHomeSampling, 1);
}

//
// Test des ganzen Versuchsgeschehens
//
void TestRotationMove (int No_Steps)
{
    // Test "Sampling Position anfahren"
    MoveTo(No_Steps, -1);  
    
    // Laser an
    Laser_ON();        
    // Test "Messung"
    CyDelay(1000);
    // Laser aus
    Laser_OFF();
    
    // 50 Schritte entspricht Drehung um 90° beim verwendeten Schrittmotor
    // Test "Pick Up Position anfahren"
    MoveTo(No_Steps, 1); 
    
    // Laser an
    Laser_ON();        
    // Test "Warten auf Lamellen PickUp"
    CyDelay(500);
    // Laser aus
    Laser_OFF(); 
}

//
// neue Lamelle ausgehend von der Samplingposition holen
//
void MoveToHomeToSamplingPositions (void)
{
    // Rahmen in Pickup-Position fahren
    MoveToHomePosition();
    // Warten
    CyDelay(LamellaFormationTime_ms);
    // Rahmen in Sampling-Position fahren
    MoveToSamplingPosition();
}

#endif // STEPPERMOTOR_CONTROL_H