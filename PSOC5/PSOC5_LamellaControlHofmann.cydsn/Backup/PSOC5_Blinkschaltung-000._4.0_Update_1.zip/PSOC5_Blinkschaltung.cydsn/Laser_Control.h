#ifndef LASER_CONTROL_H
#define LASER_CONTROL_H

#include <project.h>

//
// Laser anschalten
// 
void Laser_ON (void)
{
    Pin_LaserEN_Write(1);
}

//
// Laser ausschalten
// 
void Laser_OFF (void)
{
    Pin_LaserEN_Write(0);
}

#endif // LASER_CONTROL_H