#ifndef NEXTIONLCD_PLOTPARAMETERS_H
#define NEXTIONLCD_PLOTPARAMETERS_H

// Radius der geplotteten Kreise
#define Settings_MarkSize 3

// Dimensionierung der Zeichenflächen
#define Nextion_plot_LiveData_x 70
#define Nextion_plot_LiveData_y 60
#define Nextion_plot_LiveData_w 380
#define Nextion_plot_LiveData_h 180
// Dimensionierung der Zeichenflächen
#define Nextion_plot_ScaledData_x 70
#define Nextion_plot_ScaledData_y 60
#define Nextion_plot_ScaledData_w 380
#define Nextion_plot_ScaledData_h 180
// Dimensionierung der Zeichenflächen
#define Nextion_plot_Settings_x 70
#define Nextion_plot_Settings_y 60
#define Nextion_plot_Settings_w 380
#define Nextion_plot_Settings_h 180

//#define Nextion_plot_LiveData_xmax 7000

// Maximal und Minimalerte für Settings-Plot
#define Nextion_plot_Settings_xmax 100          // Immer 100 Messwerte auf x-Achse
#define Nextion_plot_Settings_ymax 4095         // Maximalwerts des 12bit ADC, also 2^12

// Anzahl der "Bins" für Plot in "ScaledData"
// Maximal sinnvoll: Nextion_plot_ScaledData_w/(2*Settings_MarkSize); hier ist das 63; ansonsten überlappen die dargestellten Kreise
#define NumberOfBins 30

// Anzahl der "Bins" für Plot in "LiveData"
// Maximal sinnvoll: Nextion_plot_ScaledData_w/(2*Settings_MarkSize); hier ist das 63; ansonsten überlappen die dargestellten Kreise
#define NumberOfShowResults 61

#endif // NEXTIONLCD_PLOTPARAMETERS_H    