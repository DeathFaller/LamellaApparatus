#ifndef MEASUREMENT_SETUP_H
#define MEASUREMENT_SETUP_H
    
#include <project.h>
#include <math.h>

#include "NextionLCD_Communication.h"

//
// Bestimmung der Zahl der Messungen und Initialisierungen so weit möglich
//
void Measurement_Init_Number(void)
{
    double slider_val;
    
    // Momentanen Sliderwert abragen
    slider_val = Nextion_GetSliderValue();
    // Slider-Wert auf 10 runden
    slider_val = round(slider_val/10)*10;
    // neuen Slider-Wert in slider und Anzeigetext setzen
    Nextion_SendSliderValue((int)slider_val);
    Nextion_SendTextNoMeas((int)slider_val);
    
    // Dimensionierung des maximalen Wertes der x-Achse in plot "LiveData"
    //#define Nextion_plot_LiveData_xmax 7000  
    //#define Nextion_plot_LiveData_xmax slider_val 
}

#endif // MEASUREMENT_SETUP_H