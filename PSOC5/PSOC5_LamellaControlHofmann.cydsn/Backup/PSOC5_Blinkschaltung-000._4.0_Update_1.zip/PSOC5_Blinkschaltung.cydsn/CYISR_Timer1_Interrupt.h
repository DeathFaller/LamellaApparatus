#ifndef CYISR_TIMER1_INTERRUPT_H
#define CYISR_TIMER1_INTERRUPT_H
    
#include <project.h>
#include <stdlib.h>

#include"Measurement_Parameters.h"

// 
// Timer mit 1ms Takt -> von ihm kann man mittels Zählvariablen "langsamere" Timer ableiten
//
CY_ISR(Timer1_Interrupt_Function)
{
    // Zähler alle 1ms Inkrementieren
    cnt_timer100ms++;
    cnt_timer1000ms++;
    cnt_timer5000ms++;
    
    // Timerflag für 100ms Timer setzen
    if (cnt_timer100ms == 100)
    {   
        // Zähler für diesen Counter zurücksetzen
        cnt_timer100ms = 0;
        // Variable, dass Timer gelaufen ist nur dann umschalten, wenn nicht gerade eine neue Lamelle geholt wird.
        if (new_pickup_initialized == 0)
        {
            timerflag100ms = 1;                      // globale Variable, die angibt, dass die Timerfunktion uasgelöst wurde
        }
    }
    
    // Timerflag für 1000ms Timer setzen
    if (cnt_timer1000ms == 1000)
    {   
        // Zähler für diesen Counter zurücksetzen
        cnt_timer1000ms = 0;
        timerflag1000ms = 1;                      // globale Variable, die angibt, dass die Timerfunktion uasgelöst wurde

    }   
    
    // Timerflag für 5000ms Timer setzen
    if (cnt_timer5000ms == 5000)
    {   
        // Zähler für diesen Counter zurücksetzen
        cnt_timer5000ms = 0;
        timerflag5000ms = 1;                      // globale Variable, die angibt, dass die Timerfunktion uasgelöst wurde

    }    
}

#endif // CYISR_TIMER1_INTERRUPT_H