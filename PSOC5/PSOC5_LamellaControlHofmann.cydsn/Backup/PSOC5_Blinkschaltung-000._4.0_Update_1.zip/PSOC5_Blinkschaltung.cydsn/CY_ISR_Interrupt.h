#ifndef CY_ISR_INTERRUPT_H
#define CY_ISR_INTERRUPT_H
    
#include <project.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>                                 // enthält u.a. itoa

#include "NextionLCD_Communication.h"
#include "StepperMotor_Control.h"
#include "DataLogger.h"


CY_ISR(UART_TFT_InterruptFunction)
{
    static uint8 counter = 0;                      // Laufvariable
    
    // letztes Byte einlesen
    uint8 last_byte;
    last_byte = UART_TFT_GetChar();                
    
    if (slider_val_sent == 0)
    {        
        // Fallunterscheidung bzw. Abrage der momentanen Menüseite
        if (last_byte == 0x48)                              // LCD hat ein "H" gesendet; -> ASCII "H" steht für "Home"
        {
            menustate = 0;                                  // von Nextion aus: Wechsel auf "Home" Screen
        }
        
        if (last_byte == 0x53)                              // LCD hat ein "S" gesendet; -> ASCII "S" steht für "Settings"
        {
            menustate = 1;                                  // von Nextion aus: Wechsel auf "Settings" Screen
        }
        
        if (last_byte == 0x4D)                              // LCD hat ein "M" gesendet -> Messung starten oder Abbrechen; -> ASCII "M" steht für "Measurement"
        {
            menustate = 2;                                  // von Nextion aus: Wechsel auf "LiveData" Screen   
            
            // Togglen der Variable, die angibt, ob die Messung läuft  
            if (Measurement_running == 0)
            {   
                // Vor Beginn der Messung Zieldatei für Reflektivität, *.lam, erstellen
                //OpenLoggerFile();
                // Zu Beginn Messposition anfahren
                MoveToSamplingPosition();
                Measurement_running = 1; 
                // Zähler zurücksetzen
                counter_Timer1_steps = 0;                   // Zähler für Durchläufe der Timerfuktion 
                counter_Lamella_Number = 0;                 // Zähler für die Anzahl der zu betrachtenden Lamellen
                // Werte, die neu erhalten werden als nicht gespeichert setzen
                STI100_present_results_saved = 0;
                // Maximallebensdauer zurücksetzen
                Lifetime_max = 0;
                // Ergebnisarray reinitialisieren;
                int i;
                for (i=0;i<1000;i++)
                {
                    Number[i] = 0;
                    Lifetime[i]= 0;
                }
                // erlauben, dass der 100ms Messtimer wieder feuert
                new_pickup_initialized = 0;
            }
            else if (Measurement_running == 1)
            {
                // Messung wird abgebrochen
                Measurement_running = 0; 
                // Momentanes File des Datenloggers schliessen
                CloseLoggerFile();
            }
                      
        }
        
        if (last_byte == 0x41)                              // LCD hat ein "A" gesendet; -> ASCII "A" steht für "Analysis"
        {
            menustate = 3;                                  // von Nextion aus: Wechsel auf "Scaled Data" Screen
        }
        
        if (last_byte == 0x45)                              // LCD hat ein "E" gesendet; -> ASCII "E" steht für "Export" 
        {
            menustate = 4;                                  // von Nextion aus: Wechsel auf "Export" Screen
        }
        
        if (last_byte == 0x4C)                              // LCD hat ein "L" gesendet; -> ASCII "L" stehte für Live Data
        {
            // hier nur auslesen der Bereits gesammelten Werte
            menustate = 2;                                  // von Nextion aus: Wechsel auf "Export" Screen
        }
        
        if (last_byte == 0x58)                              // LCD hat ein "X" gesendet; -> Touch Release Event des sliders mit eigenen Start Byte -> ASCII "X"
        {
            menustate = 0;
            slider_val_sent = 1;
        }
        
        if (last_byte == 0x2B)                              // LCD hat ein "+" gesendet von "Settings" Screen aus;                     
        {
            // Einen Schritt nach rechts drehen
            MoveOneStep_CounterClockwise();
        }
 
        if (last_byte == 0x2D)                              // LCD hat ein "-" gesendet von "Settings" Screen aus;                     
        {
            // Einen Schritt nach links drehen
            MoveOneStep_Clockwise();
        }
        
        if (last_byte == 0x54)                              // LCD hat ein "T" gesendet von "Settings" Screen aus;                     
        {
            // neue Lamelle ausgehend von der Samplingposition holen
            // -> während des Justierungsprozesses
            MoveToHomeToSamplingPositions();
        }
        
        if (last_byte == 0x21)                              // LCD hat ein "!" gesendet von "Settings" Screen aus;                     
        {
            // Pick-Up-Position anfahren
            MoveToHomePosition();
        }  
        
        if (last_byte == 0x55)                              // LCD hat ein "U" gesendet von "Export" Screen aus;                     
        {
            // Ergebnisse auf USB-Stick schreiben
            STI100_write_requested = 1;
        }  
    }

    // wenn der Screen ein "X" gesendet hat -> nächste 4 Bytes einlesen auf Indices 0, 1, 2, 3
    if (slider_val_sent == 1)
    {
        RX_Buffer[counter++] = last_byte;                   // Post-Inkrement; erst alten Wert nehmen, dann inkrementieren
        if (counter == 4)
        {
            counter = 0;            
            slider_val_sent = 0;
            slider_val_received = 1;
        }        
    }

}

#endif // CY_ISR_INTERRUPT_H