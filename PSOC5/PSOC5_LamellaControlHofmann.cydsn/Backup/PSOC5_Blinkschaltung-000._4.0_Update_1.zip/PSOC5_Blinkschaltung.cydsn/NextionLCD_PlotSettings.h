#ifndef NEXTIONLCD_PLOTSETTINGS_H
#define NEXTIONLCD_PLOTSETTINGS_H
    
#include <project.h>
#include <math.h>
#include <stdlib.h>                             // enthält u.a. itoa

//
// Achtung!!! #ifndef #define #endif-Konstruktion zur Vermeidung von doppelten Definitione
//
#include "NextionLCD_Communication.h"                // Funktionen für Kommunikation mit dem LCD-Display
#include "Measurement_Setup.h"
#include "NextionLCD_PlotParameters.h"


//
// Messpunkt in "Settings" einzeichnen
//
void PointsToSettingsAxes(float presence_ths, float ref_ths, float intensity)
{
    // Hilfsvariable mit 20 Zeichen
    char num_str[20];
    
    // Umskalieren der Werte, sodass sie in Zeichenfläche liegen, maximaler erlaubter Plotwert = 255
//    presence_ths = 255.0*(1.0*presence_ths/Nextion_plot_Settings_ymax);
//    ref_ths = 255.0*(1.0*ref_ths/Nextion_plot_Settings_ymax);
//    intensity = 255.0*(1.0*intensity/Nextion_plot_Settings_ymax);

    // bescheuerte Skalierung!!!! Höhe im Nextion Editor is massgeblich
    presence_ths = 1.0*Nextion_plot_Settings_h*(1.0*presence_ths/Nextion_plot_Settings_ymax);
    ref_ths = 1.0*Nextion_plot_Settings_h*(1.0*ref_ths/Nextion_plot_Settings_ymax);
    intensity = 1.0*Nextion_plot_Settings_h*(1.0*intensity/Nextion_plot_Settings_ymax);
    
    // -> setze jeweiligen Wert in Kanäle 0, 1 und 2 der Zeichenfläche mit ID 2
    
    // Wert für Detektionsgrenze -> darunter wird die Zeitmessung gestoppt
    UART_TFT_PutString("add 2,0,");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa((int)presence_ths, num_str, 10);
    UART_TFT_PutString(num_str);
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff); 
    
    // Wert für Autokalibrierung -> wenn überschritten, ist das die Sampling Position
    UART_TFT_PutString("add 2,1,");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa((int)ref_ths, num_str, 10);
    UART_TFT_PutString(num_str);
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff); 
    
    // Momentaner Wert vom ADC
    UART_TFT_PutString("add 2,2,");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa((int)intensity, num_str, 10);
    UART_TFT_PutString(num_str);
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff); 
    
//    // Maximal möglicher Wert vom ADC
//    UART_TFT_PutString("add 2,3,");
//    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
//    itoa((int)Nextion_plot_Settings_ymax, num_str, 10);
//    UART_TFT_PutString(num_str);
//    // Ende der Eingabe markieren
//    UART_TFT_PutChar(0xff);
//    UART_TFT_PutChar(0xff);
//    UART_TFT_PutChar(0xff);     
}

#endif // NEXTIONLCD_PLOTSETTINGS_H