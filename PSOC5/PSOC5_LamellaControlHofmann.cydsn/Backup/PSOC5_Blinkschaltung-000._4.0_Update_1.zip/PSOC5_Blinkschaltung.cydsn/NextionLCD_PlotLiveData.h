#ifndef NEXTIONLCD_PLOTLIVEDATA_H
#define NEXTIONLCD_PLOTLIVEDATA_H

#include <project.h>
#include <math.h>
#include <stdlib.h>

//
// Achtung!!! #ifndef #define #endif-Konstruktion zur Vermeidung von doppelten Definitione
//
#include "NextionLCD_Communication.h"                // Funktionen für Kommunikation mit dem LCD-Display
#include "Measurement_Setup.h"
#include "NextionLCD_PlotParameters.h"

//
// Messpunkt in DataLive einzeichnen
//
void PointToLiveDataAxes (float x, float y)
{
    // Hilfsvariable mit 20 Zeichen
    char num_str[20];
    
    // Umskalieren des Wertes, sodass er in Zeichenfläche liegt
    //x = Nextion_plot_LiveData_x+Nextion_plot_LiveData_w*((x-1.0)/(1.0*NumberOfMeasurements-1.0));       // Plot-Fenster im Bereich [1,NumberOfMeasurements]
    x = Nextion_plot_LiveData_x+Nextion_plot_LiveData_w*((x-1.0)/(1.0*NumberOfMeasurements-1.0));       // Plot-Fenster im Bereich [1,NumberOfMeasurements]   
    y = Nextion_plot_LiveData_y+Nextion_plot_LiveData_h*(1-y/Lifetime_max);                             // Plot-Fenster im Bereich [0,Lifetime_max]
    
    // Zielstring "cir x-Koordinate,y-Koordinate,Radius,Farbe"
    UART_TFT_PutString("cirs ");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(x, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa((int)y, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Mark Size übertragen
    itoa(Settings_MarkSize, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(',');
    // Farbe übertragen
    UART_TFT_PutString("RED");
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);     
}

#endif // NEXTIONLCD_PLOTLIVEDATA_H