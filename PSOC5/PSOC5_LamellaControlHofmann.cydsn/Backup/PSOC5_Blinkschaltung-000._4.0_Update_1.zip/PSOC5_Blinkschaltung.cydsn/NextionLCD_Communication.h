#ifndef NEXTIONLCD_COMMUNICATION_H
#define NEXTIONLCD_COMMUNICATION_H

#include <project.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>         // enthält die itoa Funktion

#include "CY_ISR_Interrupt.h"


//
// Initialisierung des TFT-Screens mit page "Home"
//
void Init_NextionTFT (void)
{
    // Starten des TFT, enthält die entsprechenede "Init" und "Enable" Funktionen
    UART_TFT_Start();
    CyDelay(1000);
    
    // Anzeigen des Home-Screens bei Initialisierung
    UART_TFT_PutString((char*)"page Home");
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
//    CyDelay(100);
    
//    // Reset des GUI bei Initialisierung
//    UART_TFT_PutString((char*)"rest");
//    UART_TFT_PutChar(0xff);
//    UART_TFT_PutChar(0xff);
//    UART_TFT_PutChar(0xff);
//    CyDelay(200);
//    UART_TFT_Start();
//    CyDelay(1000);    

//    // Show Button unsichtbar machen
//    UART_TFT_PutString("vis b_show,0");
//    // Anfrage absenden
//    UART_TFT_PutChar(0xFF);
//    UART_TFT_PutChar(0xFF);  
//    UART_TFT_PutChar(0xFF);    
}

//////////
////////// Ersatz für floor der math.lib -> ist eigentlich für PSCO4 gemacht, weil er weniger internen Speicher hat
//////////
////////int ifloor(float x)
////////{
////////	if (x >= 0.0f)
////////	{
////////		return ((int)x);
////////	}
////////	else
////////	{
////////		return ((int)x - 1);
////////	}
////////}

////////// 
////////// Float -> ASCII-Umwandlung; x Float Wert zum Umwandeln, f anzahl der Stellen 
////////// z.B. 3; str Ergebnisstring; Laufzeit: 144 us
//////////
////////void ftoa (float x,int f,char *str)
////////{
////////	float scale; /* scale factor */
////////	int i,d; /* copy of f, and # digits before decimal point */
////////	/* a digit */
////////	if( x < 0.0 )
////////	{
////////		*str++ = '-' ;
////////		x = -x ;
////////	}
////////    else
////////    {
////////        *str++ = '+' ;
////////    }
////////	i = f ;
////////	scale = 2.0 ;
////////	while ( i-- ) scale *= 10.0 ;
////////	x += 1.0 / scale ;
////////	/* count places before decimal & scale the number */
////////	i = 0 ;
////////	scale = 1.0 ;
////////	while ( x >= scale )
////////	{
////////		scale *= 10.0 ;
////////		i++ ;
////////	}
////////	if ( i == 0 ) *str++ = '0';
////////	while ( i-- )
////////	{
////////		/* output digits before decimal */
////////		// returns the value of parameter x rounded down to the nearest integer
////////        // floor find the nearest integer less than or equal to x. 
////////        scale = ifloor(0.5 + scale * 0.1 ) ;
////////		// scale = (int)(0.5 + scale * 0.1) ;
////////		d = ( x / scale ) ;
////////		*str++ = d + '0' ;
////////		x -= (float)d * scale ;
////////	}
////////	if ( f <= 0 )
////////	{
////////		*str = 0;
////////		return ;
////////	}
////////	*str++ = ',' ;  // Komma oder Punkt
////////	while ( f-- )
////////	{
////////		/* output digits after decimal */
////////		x *= 10.0 ;
////////		d = x;
////////		*str++ = d + '0' ;
////////		x -= d ;
////////	}
////////	*str = 0;
////////}

////////////
//////////// Schreibt eine 16-Bit-Zahl in die LCD-Anzeige
////////////
//////////void myitoa(int a, char *str, unsigned char vkstellen, char nullflag)
//////////{ unsigned char idx; 		/*Schleifenzähler*/
//////////  unsigned int div = 10000; /*Teilen bei int max 10000*/
//////////  unsigned int buff; 		/*Temp*/ 
//////////  unsigned char flag = 1; 	/*Flag wird für Nullunterdrückung benötigt*/
//////////  unsigned char Ausgabe; 	/*Ausgabe Wert für String*/
//////////  flag=0;
//////////  for(idx=5;idx>0;idx--) 	/*Schleife 5* für 10000er Stelle*/
//////////  { buff = a;
//////////    buff = buff / div;
//////////    if(flag == 0)
//////////    { if(buff >0)
//////////      { flag = 1;
//////////      }
//////////    }
//////////    Ausgabe = buff + 48; /*Umrechnung für Ergebnis String*/
//////////    // ggf. Leerstellenunterdrückung 
//////////	if(flag == 0)
//////////    { if(idx<=vkstellen)
//////////	  { if(nullflag==0) 
//////////	    // { if (idx>1) *str++=254;
//////////	    { if (idx>1) *str++=' ';        
//////////		  else       *str++=48;  // Sonderfall a=0 !
//////////	    }
//////////		else         *str++=48; 
//////////	  } /*Nullunterdrückung durch Leerzeichen*/
//////////    }
//////////	else
//////////	{ *str++=Ausgabe; }
//////////	a = a - (buff * div);
//////////    div = div/10;
//////////  }
//////////  *str++=0;
//////////}

//
// Abfragen des Slider-Values
//
int Nextion_GetSliderValue (void)
{  
    int slider_value = 1;
    
    // Anfrage an Sliderstellen
    UART_TFT_PutString((char*)"get slider.val");
    // Anfrage absenden
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);  
    
    return slider_value;
}

//
// Senden des Slider-Values
//
void Nextion_SendSliderValue (int new_slider_value)
{      
    // Hilfsvariable mit 20 Zeichen, in der slider-Wert als char gespeichert wird
    char num_str[20];
    
    // neuen Wert setzen
    UART_TFT_PutString((char*)"slider.val=");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(new_slider_value, num_str, 10);
    UART_TFT_PutString(num_str);
    // Anfrage absenden
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);  
}

//
// Senden eines Textes an Textfeld im "Home"-Screen
//
void Nextion_SendTextNoMeas (int new_value)
{      
    // neuen Wert setzen
    UART_TFT_PutString((char*)"e_no_meas.val=");
    UART_TFT_PutString((char*)new_value);
    // Anfrage absenden
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);  
}


void Nextion_Send_String(unsigned char *sfloat)
{
        UART_TFT_PutString((char*)sfloat);
        UART_TFT_PutChar(0xFF);
        UART_TFT_PutChar(0xFF);  
        UART_TFT_PutChar(0xFF);          
}

//
// Toggle (=Kippschalter) für Show-Button, wenn die Messung läuft
//
void Nextion_Toggle_b_show (void)
{
    int bool_measurement_running = 1;    
    // Variablenwert von "b_meas_running" auslesen
    
    // wenn Messung läuft
    if (bool_measurement_running == 1)
    {
        // Show Button anzeigen
        UART_TFT_PutString((char*)"vis b_show,1");
        // Anfrage absenden
        UART_TFT_PutChar(0xFF);
        UART_TFT_PutChar(0xFF);  
        UART_TFT_PutChar(0xFF);           
    }
    // wenn keine Messung läuft
    else
    {
        // Show Button unsichtbar machen
        UART_TFT_PutString((char*)"vis b_show,0");
        // Anfrage absenden
        UART_TFT_PutChar(0xFF);
        UART_TFT_PutChar(0xFF);  
        UART_TFT_PutChar(0xFF);
    }
    
}

//
// Text an Textbox senden
//
void Nextion_Send_Text_to_Textbox(unsigned char *textbox,unsigned char *sfloat)
{
    UART_TFT_PutString((char*)textbox);
    UART_TFT_PutString(".txt=\""); 
    UART_TFT_PutString((char*)sfloat);
    UART_TFT_PutString((char*)"\"");
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);          
}

//
// Senden eines Textes an Textfeld im "Home"-Screen
//
void Nextion_Send_Value_To_Valuebox (char *valuebox, int new_value)
{      
    // Hilfsvariable mit 20 Zeichen, in der slider-Wert als char gespeichert wird
    char num_str[20];
    
    // neuen Wert setzen
    UART_TFT_PutString((char*)valuebox);
    UART_TFT_PutString((char*)"int_now.val=");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(new_value, num_str, 10);
    UART_TFT_PutString((char*)new_value);
    // Anfrage absenden
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);  
}

////////void Nextion_Send_Value_to_Textbox(unsigned char *textbox,float value)
////////{
////////    char sfloat[10];
////////    // Float anzeigewert to ASCII
////////    ftoa(value,3,sfloat);    
////////    UART_TFT_PutString((char*)textbox);
////////    UART_TFT_PutString(".txt=\""); 
////////    UART_TFT_PutString((char*)sfloat);
////////    UART_TFT_PutString((char*)"\"");
////////    UART_TFT_PutChar(0xFF);
////////    UART_TFT_PutChar(0xFF);  
////////    UART_TFT_PutChar(0xFF);          
////////}

//
// Stellwert des Progessbar setzen; Werte von 0 bis 100
//
void Nextion_SendProgressbarValue(unsigned int value)
{
    // Hilfsvariable mit 20 Zeichen, in der slider-Wert als char gespeichert wird
    char num_str[20];

    UART_TFT_PutString((char*)"p_main.val=");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(value, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);          
}

//
// Button "Save to USB" auf Export Seite unishctbar machen
//
void Nextion_HideButtonSaveToUSB(void)
{
    UART_TFT_PutString((char*)"vis b_save,0");
    // Ende der Eingabe markieren
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);
    UART_TFT_PutChar(0xff);         
}

//
// Stellwert des Progessbar setzen; Werte von 0 bis 100
//
void Nextion_SendSaveProgressbarValue(unsigned int value)
{
    // Hilfsvariable mit 20 Zeichen, in der slider-Wert als char gespeichert wird
    char num_str[20];

    UART_TFT_PutString((char*)"slider_saved.val=");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(value, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);          
}

//
// Stellwert des Sliders auslesen und aauf 10 gerundet an die Value Box übergeben;
// diese Zahl ist dann die Anzahl der Messungen
//
int Nextion_NumberOfMeasurementsFromSlider (void)
{        
    int slider_value = (RX_Buffer[1]+RX_Buffer[2]*256)*10;      // zehnfachen Wert des Sliders als Rückgabewert
    
    UART_TFT_PutString((char*)"e_no_meas.val=");
    // Umwandlung Integer -> Array of char ("String") x_str im Decimalsystem
    itoa(slider_value, num_str, 10);
    UART_TFT_PutString(num_str);
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);   
    
    return slider_value;
}

//
// Show-Button passend anzeigen
//
void Nextion_ToggleShowButton (void)
{
    // Wenn die Messung läuft
    if (Measurement_running == 1)
    {
        // Show Button sichtbar machen
        UART_TFT_PutString("vis b_show,1");
        UART_TFT_PutChar(0xff);
        UART_TFT_PutChar(0xff);
        UART_TFT_PutChar(0xff); 
    }
    // Wenn die Messung noch nicht gestartet wurde
    else
    {
        // Show Button unsichtbar machen
        UART_TFT_PutString("vis b_show,0");
        UART_TFT_PutChar(0xff);
        UART_TFT_PutChar(0xff);
        UART_TFT_PutChar(0xff);
    }   
}

#endif // NEXTIONLCD_COMMUNICATION_H