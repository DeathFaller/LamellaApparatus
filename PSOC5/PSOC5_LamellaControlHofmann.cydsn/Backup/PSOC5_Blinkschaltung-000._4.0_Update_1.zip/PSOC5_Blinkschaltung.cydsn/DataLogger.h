// "Include-Guard" für "Datalogger.h"
#ifndef DATALOGGER_H
#define DATALOGGER_H

#include <project.h>
#include <stdio.h>      // -> für "sprintf", etc.
#include <stdlib.h>
#include <FS.h>         // für Data-Handling über SD-Karte

    
// Counter für Experiment-Nummer nach neuer Programmierung/Kompilierung bei "1" starten lassen
static const uint8 CYCODE eepromArray[]= { 0x00, 0x00, 0x00, 0x01 };
// Counter für Experiment-Nummer nach neuer Programmierung bei "0" starten lassen
//static const uint8 CYCODE eepromArray[]= { 0x00, 0x00, 0x00, 0x00 };

// Counter für EEMPROM als uint8 definieren
uint8 eeprom_cnt;
// status als Vauriable der Klasse cystatus definieren = Rückgabewert von EEPROM_Write()
cystatus status;
// pointer "ptr" definieren
volatile const uint8 *ptr;    

char FileNameCurrentLamellaFile[20];    
int bool_NewLamellaFileNameSet = 0;                 // Boolean, die angibt, ob der Name der Datei, in die gelogt wird bereits existiert

const int AllDataPointLoggerTimeLimit_s = 900;      // Zeit unterhalb der jeder gemessen Datenpunkt gelogt wird (900s = 15min)

FS_FILE *FileNameLogger;                            // Pointer auf Datei, die gelogte Daten enthält                 


// 
// Logger-File öffnen
//
void OpenLoggerFile(void)
{
    // Pointer auf die Adresse des letzten (= 4.) Eintrag des EEPROM-Arrays setzen
    ptr = &eepromArray[3];
    // Dereferenzieren des Pointers -> Wert, auf den "ptr" zeigt in "eeprom_cnt" abspeichern
    eeprom_cnt = *ptr;
    // Name der Datei festlegen, in die Reflektivitäten der aktuellen Lamelle geschrieben werden sollen
    sprintf((char*)FileNameCurrentLamellaFile, "%d-%d.lam", eeprom_cnt, (int)(counter_Lamella_Number+1)); 
    UART_TFT_PutString("t0.txt=\""); 
    UART_TFT_PutString((char*)FileNameCurrentLamellaFile);
    UART_TFT_PutString((char*)"\"");
    UART_TFT_PutChar(0xFF);
    UART_TFT_PutChar(0xFF);  
    UART_TFT_PutChar(0xFF);
    // Logger-File zum Schreiben öffnen
    FileNameLogger = FS_FOpen(FileNameCurrentLamellaFile, "w");
    CyDelay(100);
    
    int OpeningTry = 0;
    while (FileNameLogger == 0)
    {
    	OpeningTry += 1;
    	// neuen Wert setzen
    	UART_TFT_PutString((char*)"e_no_meas.val=");
    	sprintf(num_str, "%d", OpeningTry);
    	UART_TFT_PutString(num_str);
    	// Anfrage absenden
    	UART_TFT_PutChar(0xFF);
    	UART_TFT_PutChar(0xFF);  
    	UART_TFT_PutChar(0xFF);  
        UART_TFT_PutString("t0.txt=\""); 
        UART_TFT_PutString((char*)FileNameCurrentLamellaFile);
        UART_TFT_PutString((char*)"\"");
        UART_TFT_PutChar(0xFF);
        UART_TFT_PutChar(0xFF);  
        UART_TFT_PutChar(0xFF);
    	
    	// Logger-File zum Schreiben öffnen
    	FileNameLogger = FS_FOpen(FileNameCurrentLamellaFile, "w");
        CyDelay(100);
    	
    	// Maximal 100 Öffnungsversuche
    	if (OpeningTry == 100)
    	{
    		break;
    	}
    }    
}


//
// Logger für Intensität aus einem Kanal
//
void IntensityLogger_ONE_Channel(int NumberOfEntry, int value)
{
    char buffer_Lamella_nextline[10];               // Puffer für nächste zu schreibende Zeile
    
    //
    // unterhalb der Grenzzeit wir jede gemessene Reflektivität geloggt
    //
    if  (NumberOfEntry <= (int)(AllDataPointLoggerTimeLimit_s*SampligCountsPerSecond))
    {        
        // nächste Zeile in "buffer_Lamella_nextline" abspeichern
        sprintf((char*)buffer_Lamella_nextline, "%.1f,%d\n", ((float)NumberOfEntry)/10, value);
        // gepufferte Zeile in Ergebnisdatei schreiben
        if (0 != FS_Write(FileNameLogger, buffer_Lamella_nextline, strlen(buffer_Lamella_nextline)))
        {
            // kein Fehler
        } 
        else
        {
            // Fehlerbehandlung
        }
    }
    //
    // --> hier alle "counter_Lamella_Logger_steps" = 1[s] mit Hilfe des Modulo-Operators (%) 
    // Nach mehr als 900 [s] (= 15 Minuten) Lebenszeit Reflektivität nut noch jede Sekunde loggen 
    //
    else
    {
        if (NumberOfEntry%SampligCountsPerSecond == 0)
        {
            // nächste Zeile in "buffer_Lamella_nextline" abspeichern
            sprintf((char*)buffer_Lamella_nextline, "%.1f,%d\n", ((float)NumberOfEntry)/10, value);
            // gepufferte Zeile in Ergebnisdatei schreiben
            if (0 != FS_Write(FileNameLogger, buffer_Lamella_nextline, strlen(buffer_Lamella_nextline)))
            {
                // kein Fehler
            } 
            else
            {
                // Fehlerbehandlung
            }
        }        
    }
}


//
// Logger-Datei schliessen
//
void CloseLoggerFile (void)
{
    // Schliessen der Datei, in die geschrieben wurde
    int retValFS_FClose = FS_FClose(FileNameLogger);
    if(retValFS_FClose == 0)
    {
        // alles ok
    }
    else
    {
       // Schliessen solange Wiederholen, bis kein Fehler mehr
        while (retValFS_FClose != 0)
        {
            // Fehler -> "Fehler beim Schliessen"
            UART_TFT_PutString((char*)"t_Stat.txt=\"ERROR C.\"");
            // Ende der Eingabe markieren
            UART_TFT_PutChar(0xff);
            UART_TFT_PutChar(0xff);
            UART_TFT_PutChar(0xff);
            
            // erneuter Versuch, die Datei zu schliessen
            retValFS_FClose = FS_FClose(FileNameLogger);
            CyDelay(10);
        }
    } 
    CyDelay(200);
}

#endif // DATALOGGER_H