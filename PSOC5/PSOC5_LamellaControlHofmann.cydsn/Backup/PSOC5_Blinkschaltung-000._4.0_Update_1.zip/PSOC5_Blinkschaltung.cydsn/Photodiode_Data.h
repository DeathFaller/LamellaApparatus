#ifndef PHOTODIODE_DATA_H
#define PHOTODIODE_DATA_H    

#include <project.h>
#include <math.h>                   // Mathe-Modul -> erlaubt unter anderem "NAN"-Werte

//
// Selbstständige Suche der Referenzposition mit Intensittät oberhalb Schwellwert
//
void AutoCalibration (void)
{
}

// 
// Aufnahme eines Messwertes -> Fahren von Home-Position in Sampling Position und
// wieder zurück in Home-Position
//
long Get_Single_Lamella_Lifetime (void)
{
    float LifeTime = NAN;            // Initialisierung des Rückgabewerts als "Not A Number"
    
    return LifeTime;
}

#endif // PHOTODIODE_DATA_H