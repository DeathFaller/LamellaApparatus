/*******************************************************************************
* File Name: USBUART_PC_pm.c
* Version 2.80
*
* Description:
*  This file provides Suspend/Resume APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "project.h"
#include "USBUART_PC.h"
#include "USBUART_PC_pvt.h"



/***************************************
* Custom Declarations
***************************************/
/* `#START PM_CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */


/***************************************
* Local data allocation
***************************************/

static USBUART_PC_BACKUP_STRUCT  USBUART_PC_backup;


#if(USBUART_PC_DP_ISR_REMOVE == 0u)

    /*******************************************************************************
    * Function Name: USBUART_PC_DP_Interrupt
    ********************************************************************************
    *
    * Summary:
    *  This Interrupt Service Routine handles DP pin changes for wake-up from
    *  the sleep mode.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    CY_ISR(USBUART_PC_DP_ISR)
    {
        #ifdef USBUART_PC_DP_ISR_ENTRY_CALLBACK
            USBUART_PC_DP_ISR_EntryCallback();
        #endif /* USBUART_PC_DP_ISR_ENTRY_CALLBACK */

        /* `#START DP_USER_CODE` Place your code here */

        /* `#END` */

        /* Clears active interrupt */
        CY_GET_REG8(USBUART_PC_DP_INTSTAT_PTR);

        #ifdef USBUART_PC_DP_ISR_EXIT_CALLBACK
            USBUART_PC_DP_ISR_ExitCallback();
        #endif /* USBUART_PC_DP_ISR_EXIT_CALLBACK */
    }

#endif /* (USBUART_PC_DP_ISR_REMOVE == 0u) */


/*******************************************************************************
* Function Name: USBUART_PC_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBUART_PC_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: USBUART_PC_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBUART_PC_RestoreConfig(void) 
{
    if(USBUART_PC_configuration != 0u)
    {
        USBUART_PC_ConfigReg();
    }
}


/*******************************************************************************
* Function Name: USBUART_PC_Suspend
********************************************************************************
*
* Summary:
*  This function disables the USBFS block and prepares for power down mode.
*
* Parameters:
*  None.
*
* Return:
*   None.
*
* Global variables:
*  USBUART_PC_backup.enable:  modified.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBUART_PC_Suspend(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    if((CY_GET_REG8(USBUART_PC_CR0_PTR) & USBUART_PC_CR0_ENABLE) != 0u)
    {   /* USB block is enabled */
        USBUART_PC_backup.enableState = 1u;

        #if(USBUART_PC_EP_MM != USBUART_PC__EP_MANUAL)
            USBUART_PC_Stop_DMA(USBUART_PC_MAX_EP);     /* Stop all DMAs */
        #endif   /*  USBUART_PC_EP_MM != USBUART_PC__EP_MANUAL */

        /* Ensure USB transmit enable is low (USB_USBIO_CR0.ten). - Manual Transmission - Disabled */
        USBUART_PC_USBIO_CR0_REG &= (uint8)~USBUART_PC_USBIO_CR0_TEN;
        CyDelayUs(0u);  /*~50ns delay */

        /* Disable the USBIO by asserting PM.USB_CR0.fsusbio_pd_n(Inverted) and pd_pullup_hv(Inverted) high. */
        USBUART_PC_PM_USB_CR0_REG &=
                                (uint8)~(USBUART_PC_PM_USB_CR0_PD_N | USBUART_PC_PM_USB_CR0_PD_PULLUP_N);

        /* Disable the SIE */
        USBUART_PC_CR0_REG &= (uint8)~USBUART_PC_CR0_ENABLE;

        CyDelayUs(0u);  /* ~50ns delay */
        /* Store mode and Disable VRegulator*/
        USBUART_PC_backup.mode = USBUART_PC_CR1_REG & USBUART_PC_CR1_REG_ENABLE;
        USBUART_PC_CR1_REG &= (uint8)~USBUART_PC_CR1_REG_ENABLE;

        CyDelayUs(1u);  /* 0.5 us min delay */
        /* Disable the USBIO reference by setting PM.USB_CR0.fsusbio_ref_en.*/
        USBUART_PC_PM_USB_CR0_REG &= (uint8)~USBUART_PC_PM_USB_CR0_REF_EN;

        /* Switch DP and DM terminals to GPIO mode and disconnect 1.5k pullup*/
        USBUART_PC_USBIO_CR1_REG |= USBUART_PC_USBIO_CR1_IOMODE;

        /* Disable USB in ACT PM */
        USBUART_PC_PM_ACT_CFG_REG &= (uint8)~USBUART_PC_PM_ACT_EN_FSUSB;
        /* Disable USB block for Standby Power Mode */
        USBUART_PC_PM_STBY_CFG_REG &= (uint8)~USBUART_PC_PM_STBY_EN_FSUSB;
        CyDelayUs(1u); /* min  0.5us delay required */

    }
    else
    {
        USBUART_PC_backup.enableState = 0u;
    }

    CyExitCriticalSection(enableInterrupts);

    /* Set the DP Interrupt for wake-up from sleep mode. */
    #if(USBUART_PC_DP_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBUART_PC_DP_INTC_VECT_NUM, &USBUART_PC_DP_ISR);
        CyIntSetPriority(USBUART_PC_DP_INTC_VECT_NUM, USBUART_PC_DP_INTC_PRIOR);
        CyIntClearPending(USBUART_PC_DP_INTC_VECT_NUM);
        CyIntEnable(USBUART_PC_DP_INTC_VECT_NUM);
    #endif /* (USBUART_PC_DP_ISR_REMOVE == 0u) */
}


/*******************************************************************************
* Function Name: USBUART_PC_Resume
********************************************************************************
*
* Summary:
*  This function enables the USBFS block after power down mode.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBUART_PC_backup - checked.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBUART_PC_Resume(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    if(USBUART_PC_backup.enableState != 0u)
    {
        #if(USBUART_PC_DP_ISR_REMOVE == 0u)
            CyIntDisable(USBUART_PC_DP_INTC_VECT_NUM);
        #endif /*  USBUART_PC_DP_ISR_REMOVE */

        /* Enable USB block */
        USBUART_PC_PM_ACT_CFG_REG |= USBUART_PC_PM_ACT_EN_FSUSB;
        /* Enable USB block for Standby Power Mode */
        USBUART_PC_PM_STBY_CFG_REG |= USBUART_PC_PM_STBY_EN_FSUSB;
        /* Enable core clock */
        USBUART_PC_USB_CLK_EN_REG |= USBUART_PC_USB_CLK_ENABLE;

        /* Enable the USBIO reference by setting PM.USB_CR0.fsusbio_ref_en.*/
        USBUART_PC_PM_USB_CR0_REG |= USBUART_PC_PM_USB_CR0_REF_EN;
        /* The reference will be available ~40us after power restored */
        CyDelayUs(40u);
        /* Return VRegulator*/
        USBUART_PC_CR1_REG |= USBUART_PC_backup.mode;
        CyDelayUs(0u);  /*~50ns delay */
        /* Enable USBIO */
        USBUART_PC_PM_USB_CR0_REG |= USBUART_PC_PM_USB_CR0_PD_N;
        CyDelayUs(2u);
        /* Set the USBIO pull-up enable */
        USBUART_PC_PM_USB_CR0_REG |= USBUART_PC_PM_USB_CR0_PD_PULLUP_N;

        /* Re-init Arbiter configuration for DMA transfers */
        #if(USBUART_PC_EP_MM != USBUART_PC__EP_MANUAL)
            /* Usb arb interrupt enable */
            USBUART_PC_ARB_INT_EN_REG = USBUART_PC_ARB_INT_MASK;
            #if(USBUART_PC_EP_MM == USBUART_PC__EP_DMAMANUAL)
                USBUART_PC_ARB_CFG_REG = USBUART_PC_ARB_CFG_MANUAL_DMA;
            #endif   /*  USBUART_PC_EP_MM == USBUART_PC__EP_DMAMANUAL */
            #if(USBUART_PC_EP_MM == USBUART_PC__EP_DMAAUTO)
                /*Set cfg cmplt this rises DMA request when the full configuration is done */
                USBUART_PC_ARB_CFG_REG = USBUART_PC_ARB_CFG_AUTO_DMA | USBUART_PC_ARB_CFG_AUTO_MEM;
            #endif   /*  USBUART_PC_EP_MM == USBUART_PC__EP_DMAAUTO */
        #endif   /*  USBUART_PC_EP_MM != USBUART_PC__EP_MANUAL */

        /* STALL_IN_OUT */
        CY_SET_REG8(USBUART_PC_EP0_CR_PTR, USBUART_PC_MODE_STALL_IN_OUT);
        /* Enable the SIE with a last address */
        USBUART_PC_CR0_REG |= USBUART_PC_CR0_ENABLE;
        CyDelayCycles(1u);
        /* Finally, Enable d+ pullup and select iomode to USB mode*/
        CY_SET_REG8(USBUART_PC_USBIO_CR1_PTR, USBUART_PC_USBIO_CR1_USBPUEN);

        /* Restore USB register settings */
        USBUART_PC_RestoreConfig();
    }

    CyExitCriticalSection(enableInterrupts);
}


/* [] END OF FILE */
